# Elige tu camino — versión 3

Esta es una versión separada de la anterior. La versión 2 no se modifica.

## Novedades
- Editor completo dentro de la app.
- Crear niveles.
- Eliminar niveles.
- Cambiar el nombre de cada nivel.
- Añadir rondas.
- Eliminar rondas.
- Editar situación/pregunta y las dos elecciones.
- **Crear caminos diferentes según A o B.**
- Cada elección puede llevar a cualquier otra ronda o finalizar el juego.
- Texto final diferente para cada elección cuando esa elección termina la partida.
- Los cambios se guardan en el propio móvil.
- Restaurar el juego de ejemplo.

## Cómo crear una historia ramificada
En una ronda, edita:
1. Elección A.
2. En “Después de elegir A”, selecciona la ronda a la que quieres ir.
3. Haz lo mismo para B.
4. Si eliges “Finalizar juego”, puedes escribir el resultado que aparecerá.

Así puedes crear historias del tipo:

Ronda 1
├── A → Ronda 2
└── B → Ronda 5

Ronda 2
├── A → Ronda 3
└── B → Ronda 4

Cada partida puede recorrer un camino diferente.
