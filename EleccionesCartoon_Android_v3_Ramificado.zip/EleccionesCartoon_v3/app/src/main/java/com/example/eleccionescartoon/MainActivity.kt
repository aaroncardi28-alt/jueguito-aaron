
package com.example.eleccionescartoon

import android.content.Context
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Round(
    val id: String,
    val question: String,
    val a: String,
    val b: String,
    val nextA: String? = null,
    val nextB: String? = null,
    val finalA: String = "¡Has llegado al final!",
    val finalB: String = "¡Has llegado al final!"
)

data class Level(val id: String, val title: String, val rounds: List<Round>)

private fun newId() = java.util.UUID.randomUUID().toString()

private fun defaultLevels(): List<Level> {
    val levels = (1..4).map { li ->
        Level(newId(), "Nivel $li", emptyList())
    }.toMutableList()

    for (li in levels.indices) {
        val rounds = (1..3).map { ri ->
            Round(
                id = newId(),
                question = "Situación de ejemplo ${li * 3 + ri}",
                a = "Opción A",
                b = "Opción B"
            )
        }.toMutableList()
        levels[li] = levels[li].copy(rounds = rounds)
    }

    // Default path: A and B both continue linearly, with the last round ending.
    for (li in levels.indices) {
        for (ri in levels[li].rounds.indices) {
            val r = levels[li].rounds[ri]
            val next = when {
                ri + 1 < levels[li].rounds.size -> levels[li].rounds[ri + 1].id
                li + 1 < levels.size && levels[li + 1].rounds.isNotEmpty() -> levels[li + 1].rounds[0].id
                else -> null
            }
            levels[li] = levels[li].copy(
                rounds = levels[li].rounds.toMutableList().also { list ->
                    list[ri] = r.copy(nextA = next, nextB = next)
                }
            )
        }
    }
    return levels
}

private fun levelsToJson(levels: List<Level>): String {
    val arr = JSONArray()
    levels.forEach { level ->
        val lo = JSONObject().apply {
            put("id", level.id)
            put("title", level.title)
            put("rounds", JSONArray().apply {
                level.rounds.forEach { r ->
                    put(JSONObject().apply {
                        put("id", r.id)
                        put("question", r.question)
                        put("a", r.a)
                        put("b", r.b)
                        put("nextA", r.nextA ?: "")
                        put("nextB", r.nextB ?: "")
                        put("finalA", r.finalA)
                        put("finalB", r.finalB)
                    })
                }
            })
        }
        arr.put(lo)
    }
    return arr.toString()
}

private fun jsonToLevels(raw: String): List<Level> {
    val arr = JSONArray(raw)
    return buildList {
        for (i in 0 until arr.length()) {
            val lo = arr.getJSONObject(i)
            val roundsJson = lo.optJSONArray("rounds") ?: JSONArray()
            val rounds = buildList {
                for (j in 0 until roundsJson.length()) {
                    val r = roundsJson.getJSONObject(j)
                    add(
                        Round(
                            id = r.optString("id", newId()),
                            question = r.optString("question"),
                            a = r.optString("a"),
                            b = r.optString("b"),
                            nextA = r.optString("nextA").takeIf { it.isNotBlank() },
                            nextB = r.optString("nextB").takeIf { it.isNotBlank() },
                            finalA = r.optString("finalA", "¡Has llegado al final!"),
                            finalB = r.optString("finalB", "¡Has llegado al final!")
                        )
                    )
                }
            }
            add(Level(lo.optString("id", newId()), lo.optString("title", "Nivel"), rounds))
        }
    }
}

private fun loadLevels(context: Context): List<Level> {
    val prefs = context.getSharedPreferences("game_content_v3", Context.MODE_PRIVATE)
    val raw = prefs.getString("levels_json", null)
    return if (raw == null) defaultLevels() else runCatching { jsonToLevels(raw) }.getOrElse { defaultLevels() }
}

private fun saveLevels(context: Context, levels: List<Level>) {
    context.getSharedPreferences("game_content_v3", Context.MODE_PRIVATE)
        .edit().putString("levels_json", levelsToJson(levels)).apply()
}

private fun clearLevels(context: Context) {
    context.getSharedPreferences("game_content_v3", Context.MODE_PRIVATE).edit().clear().apply()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameApp(this) }
    }
}

@Composable
fun GameApp(context: Context) {
    var levels by remember { mutableStateOf(loadLevels(context)) }
    var screen by remember { mutableStateOf("home") }
    var currentId by remember { mutableStateOf<String?>(null) }
    var lastResult by remember { mutableStateOf("") }
    var choicesMade by remember { mutableIntStateOf(0) }

    fun startGame() {
        levels = loadLevels(context)
        currentId = levels.firstOrNull()?.rounds?.firstOrNull()?.id
        choicesMade = 0
        lastResult = ""
        screen = if (currentId == null) "empty" else "game"
    }

    MaterialTheme {
        when (screen) {
            "home" -> HomeScreen(
                onStart = ::startGame,
                onEdit = { levels = loadLevels(context); screen = "editor" }
            )
            "editor" -> EditorScreen(
                initialLevels = levels,
                onCancel = { levels = loadLevels(context); screen = "home" },
                onSave = {
                    saveLevels(context, it)
                    levels = it
                    screen = "home"
                },
                onReset = {
                    clearLevels(context)
                    levels = defaultLevels()
                }
            )
            "game" -> {
                val round = levels.flatMap { it.rounds }.firstOrNull { it.id == currentId }
                if (round == null) {
                    screen = "empty"
                } else {
                    val levelTitle = levels.firstOrNull { l -> l.rounds.any { it.id == round.id } }?.title ?: ""
                    GameScreen(
                        levelTitle = levelTitle,
                        question = round.question,
                        optionA = round.a,
                        optionB = round.b,
                        choicesMade = choicesMade,
                        totalRounds = levels.sumOf { it.rounds.size },
                        onHome = { screen = "home" },
                        onChoice = { selectedA ->
                            choicesMade++
                            val next = if (selectedA) round.nextA else round.nextB
                            val final = if (selectedA) round.finalA else round.finalB
                            if (next == null) {
                                lastResult = final
                                screen = "end"
                            } else {
                                currentId = next
                            }
                        }
                    )
                }
            }
            "end" -> EndScreen(
                result = lastResult,
                choicesMade = choicesMade,
                onRestart = ::startGame,
                onHome = { screen = "home" }
            )
            else -> EmptyScreen(onHome = { screen = "home" })
        }
    }
}

@Composable
fun HomeScreen(onStart: () -> Unit, onEdit: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))
        Text("Elige tu camino", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Image(
            painterResource(R.drawable.personaje),
            contentDescription = "Personaje",
            modifier = Modifier.fillMaxWidth().height(450.dp),
            contentScale = ContentScale.Fit
        )
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(58.dp)) {
            Text("EMPEZAR", style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("✏️ EDITAR JUEGO")
        }
    }
}

@Composable
fun GameScreen(
    levelTitle: String,
    question: String,
    optionA: String,
    optionB: String,
    choicesMade: Int,
    totalRounds: Int,
    onHome: () -> Unit,
    onChoice: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(levelTitle, style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onHome) { Text("Inicio") }
        }
        LinearProgressIndicator(
            progress = { (choicesMade.coerceAtMost(totalRounds).toFloat() / totalRounds.coerceAtLeast(1)) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(42.dp))
        Text(question, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(40.dp))
        Button(onClick = { onChoice(true) }, modifier = Modifier.fillMaxWidth().height(72.dp)) {
            Text("A  •  $optionA", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { onChoice(false) }, modifier = Modifier.fillMaxWidth().height(72.dp)) {
            Text("B  •  $optionB", style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun EditorScreen(
    initialLevels: List<Level>,
    onCancel: () -> Unit,
    onSave: (List<Level>) -> Unit,
    onReset: () -> Unit
) {
    var levels by remember { mutableStateOf(initialLevels) }
    var showReset by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun allRounds(): List<Round> = levels.flatMap { it.rounds }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Editor del juego", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = onCancel) { Text("Salir") }
        }

        Text("Puedes crear/eliminar niveles y rondas y conectar cada elección con otra ronda.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        levels.forEachIndexed { li, level ->
            Card(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = level.title,
                        onValueChange = { value ->
                            levels = levels.mapIndexed { i, l -> if (i == li) l.copy(title = value) else l }
                        },
                        label = { Text("Nombre del nivel") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))

                    level.rounds.forEachIndexed { ri, round ->
                        RoundEditor(
                            round = round,
                            destinations = allRounds(),
                            onChange = { updated ->
                                levels = levels.mapIndexed { i, l ->
                                    if (i == li) l.copy(rounds = l.rounds.mapIndexed { j, r -> if (j == ri) updated else r }) else l
                                }
                            },
                            onDelete = {
                                levels = levels.mapIndexed { i, l ->
                                    if (i == li) l.copy(rounds = l.rounds.filterIndexed { j, _ -> j != ri }) else l
                                }
                            }
                        )
                    }

                    Button(
                        onClick = {
                            val r = Round(newId(), "Nueva situación", "Elección A", "Elección B")
                            levels = levels.mapIndexed { i, l -> if (i == li) l.copy(rounds = l.rounds + r) else l }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("+ Añadir ronda") }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            if (levels.size > 1) levels = levels.filterIndexed { i, _ -> i != li }
                            else message = "Debe existir al menos un nivel."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Eliminar este nivel") }
                }
            }
        }

        Button(
            onClick = {
                levels = levels + Level(newId(), "Nivel ${levels.size + 1}", listOf(
                    Round(newId(), "Nueva situación", "Elección A", "Elección B")
                ))
            },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("+ CREAR NIVEL") }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                onSave(levels)
                message = "Cambios guardados."
            },
            modifier = Modifier.fillMaxWidth().height(58.dp)
        ) { Text("💾 GUARDAR CAMBIOS") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { showReset = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Restaurar juego de ejemplo") }

        if (message.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(message)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("¿Restaurar?") },
            text = { Text("Se borrará la configuración guardada y volverá el juego de ejemplo.") },
            confirmButton = {
                TextButton(onClick = {
                    onReset()
                    levels = defaultLevels()
                    showReset = false
                }) { Text("RESTAURAR") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("CANCELAR") } }
        )
    }
}

@Composable
fun RoundEditor(
    round: Round,
    destinations: List<Round>,
    onChange: (Round) -> Unit,
    onDelete: () -> Unit
) {
    var openA by remember { mutableStateOf(false) }
    var openB by remember { mutableStateOf(false) }

    Column(Modifier.padding(vertical = 10.dp)) {
        Text("Ronda", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = round.question,
            onValueChange = { onChange(round.copy(question = it)) },
            label = { Text("Situación / pregunta") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = round.a,
            onValueChange = { onChange(round.copy(a = it)) },
            label = { Text("Elección A") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = round.b,
            onValueChange = { onChange(round.copy(b = it)) },
            label = { Text("Elección B") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        Text("Después de elegir A:", fontWeight = FontWeight.SemiBold)
        Box {
            OutlinedButton(onClick = { openA = true }, modifier = Modifier.fillMaxWidth()) {
                Text(destinationLabel(round.nextA, destinations))
            }
            DropdownMenu(expanded = openA, onDismissRequest = { openA = false }) {
                DropdownMenuItem(text = { Text("Finalizar juego") }, onClick = {
                    onChange(round.copy(nextA = null))
                    openA = false
                })
                destinations.filter { it.id != round.id }.forEach { d ->
                    DropdownMenuItem(text = { Text(destinationLabel(d.id, destinations)) }, onClick = {
                        onChange(round.copy(nextA = d.id))
                        openA = false
                    })
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = round.finalA,
            onValueChange = { onChange(round.copy(finalA = it)) },
            label = { Text("Texto final si A termina el juego") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))
        Text("Después de elegir B:", fontWeight = FontWeight.SemiBold)
        Box {
            OutlinedButton(onClick = { openB = true }, modifier = Modifier.fillMaxWidth()) {
                Text(destinationLabel(round.nextB, destinations))
            }
            DropdownMenu(expanded = openB, onDismissRequest = { openB = false }) {
                DropdownMenuItem(text = { Text("Finalizar juego") }, onClick = {
                    onChange(round.copy(nextB = null))
                    openB = false
                })
                destinations.filter { it.id != round.id }.forEach { d ->
                    DropdownMenuItem(text = { Text(destinationLabel(d.id, destinations)) }, onClick = {
                        onChange(round.copy(nextB = d.id))
                        openB = false
                    })
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = round.finalB,
            onValueChange = { onChange(round.copy(finalB = it)) },
            label = { Text("Texto final si B termina el juego") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(6.dp))
        TextButton(onClick = onDelete) { Text("Eliminar ronda") }
        HorizontalDivider()
    }
}

private fun destinationLabel(id: String?, destinations: List<Round>): String {
    if (id == null) return "Finalizar juego"
    val index = destinations.indexOfFirst { it.id == id }
    return if (index >= 0) "Ir a ronda ${index + 1}" else "Destino no encontrado"
}

@Composable
fun EndScreen(result: String, choicesMade: Int, onRestart: () -> Unit, onHome: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🎉", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(16.dp))
        Text(result, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Decisiones tomadas: $choicesMade")
        Spacer(Modifier.height(28.dp))
        Button(onClick = onRestart, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text("VOLVER A JUGAR")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) {
            Text("VOLVER AL INICIO")
        }
    }
}

@Composable
fun EmptyScreen(onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("El juego no tiene rondas.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = onHome) { Text("Volver al inicio") }
    }
}
